@extends('layouts.app')
@section('body_content')

<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-12">
                  <h3>ফিল্ম এন্ড লাইব্রেরী পণ্য / বিতরণ </h3>
                </div>
                <div class="col-12 col-sm-6">

                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <form action="{{route('t.store.sold.invoices.view')}}" method="get">
            <div class="row">
                <div class="col-sm-4">
                    <div class="card recent-activity">
                        <div class="card-header card-no-border bg-primary text-light">
                            <div class="media media-dashboard">
                                <div class="media-body"> 
                                <h5>Search Products</h5>
                                </div>
                            </div>
                            <br>
                            <input type="text" name="" class="form-control" placeholder="Search Products..." id="">
                        </div>
                    </div>
                    <div class="card recent-activity">
                        <div class="card-header card-no-border">
                        <div class="media media-dashboard border-bottom">
                            <div class="media-body"> 
                            <h5>Distributor Info</h5>
                            </div>
                        </div>
                        </div>
                        <div class="card-body pt-0">                  
                            <div class="position-relative mb-3">
                                <label class="form-label" for="validationTooltip02"> <span class="text-danger">* </span> নাম / Name</label>
                                <input class="form-control" id="" type="text" value="" required="">
                            </div>
                            <div class="position-relative mb-3">
                                <label class="form-label" for="validationTooltip02"> <span class="text-danger">* </span> মোবাইল নাম্বার / Phone Number</label>
                                <input class="form-control" id="" type="text" value="" required="">
                            </div>
                            <div class="position-relative">
                                <label class="form-label" for="validationTooltip02"> <span class="text-danger">* </span> এড্রেস  / Address</label>
                                <input class="form-control" id="" type="text" value="" required="">
                            </div>
                            
                        </div>
                    </div>
                  </div>
              <div class="col-sm-8">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th width="5%" scope="col">IMAGE</th>
                                  <th scope="col">PRODUCT NAME</th>
                                  <th width="10%" scope="col">QUANTITY</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><img width="100%" src="https://static-01.daraz.com.bd/p/b187013da2d8a455cf72e816105a2851.jpg" alt=""></td>
                                  <td>Urban District Stylish Curved Cap For men</td>
                                  <td><input type="number" name="" class="form-control" value="23" id=""></td>
                                </tr>
                                <tr>
                                  <td><img src="https://static-01.daraz.com.bd/p/2049f614574dd8aea2317aaadb4f03f0.jpg" width="100%" alt=""></td>
                                  <td>PU Leather styles long wallet for men with</td>
                                  <td><input type="number" name="" class="form-control" value="44" id=""></td>
                                </tr>
                                <tr>
                                  <td><img src="https://static-01.daraz.com.bd/p/25e6af03f267850b050c80c0f4092d4d.jpg_200x200q80-product.jpg_.webp" width="100%" alt=""></td>
                                  <td>LED Sensor Dream Mushroom Lamp - Multicolor</td>
                                  <td><input type="number" name="" class="form-control" value="67" id=""></td>
                                </tr>
                                <tr>
                                    <td><img width="100%" src="https://static-01.daraz.com.bd/p/b187013da2d8a455cf72e816105a2851.jpg" alt=""></td>
                                    <td>Urban District Stylish Curved Cap For men</td>
                                    <td><input type="number" name="" class="form-control" value="77" id=""></td>
                                  </tr>
                                  <tr>
                                    <td><img src="https://static-01.daraz.com.bd/p/mdc/b0ee3688a7deb36683e1c889a30812f3.png_200x200q80-product.jpg_.webp" width="100%" alt=""></td>
                                    <td>LED Sensor Dream Mushroom Lamp - Multicolor</td>
                                    <td><input type="number" name="" class="form-control" value="33" id=""></td>
                                  </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
              
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block">
                          <div class="row">
                            <div class="col-md-4">
                            <div class="form-group mb-3">
                                    <label class="form-check-label"><b>Date</b></label>
                                    <input class="form-control" type="date" name="date" id="InvDate" value="2022-05-31" required="">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="form-label" for="validationTooltip03">নোট / Note</label>
                                    <textarea class="form-control" name="" id="" cols="30" rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group text-right mt-3">
                            <button class="btn btn-primary" type="submit">Submit</button>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </div>
@endsection
