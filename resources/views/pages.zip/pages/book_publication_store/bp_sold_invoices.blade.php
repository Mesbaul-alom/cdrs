@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-12">
                  <h3>বিতরণ  ইনভয়েস / Distribution Invoice</h3>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th scope="col">Date</th>
                                  <th scope="col">Customer Name</th>
                                  <th width="20%" scope="col">Phone</th>
                                  <th width="20%" scope="col">Address</th>
                                  <th scope="col">Invoice Number</th>
                                  <th scope="col">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                    <th scope="row">31-05-2-22</th>
                                    <td>Sohel Mia</td>
                                    <td>01627382866</td>
                                    <td>Mirpur-10, Dhaka-1216</td>
                                    <td>S/232</td>
                                    
                                    <td>
                                      <a href="#" class="btn btn-primary">View</a> 
                                    </td>
                                  </tr>
                                  <tr>
                                    <th scope="row">31-05-2-22</th>
                                    <td>Robin Mia</td>
                                    <td>01627382866</td>
                                    <td>Mirpur-10, Dhaka-1216</td>
                                    <td>S/232</td>
                                    
                                    <td>
                                      <a href="#" class="btn btn-primary">View</a> 
                                    </td>
                                  </tr>
                                  <tr>
                                    <th scope="row">30-05-2-22</th>
                                    <td>Shagor Mia</td>
                                    <td>01627382866</td>
                                    <td>Mirpur-10, Dhaka-1216</td>
                                    <td>S/232</td>
                                    
                                    <td>
                                      <a href="#" class="btn btn-primary">View</a> 
                                    </td>
                                  </tr>
                                  <tr>
                                    <th scope="row">23-05-2-22</th>
                                    <td>Sohel Mia</td>
                                    <td>01627382866</td>
                                    <td>Mirpur-10, Dhaka-1216</td>
                                    <td>S/232</td>
                                    
                                    <td>
                                      <a href="#" class="btn btn-primary">View</a> 
                                    </td>
                                  </tr>
                                  <tr>
                                    <th scope="row">12-05-2-22</th>
                                    <td>Sohel Mia</td>
                                    <td>01627382866</td>
                                    <td>Mirpur-10, Dhaka-1216</td>
                                    <td>S/232</td>
                                    
                                    <td>
                                      <a href="#" class="btn btn-primary">View</a> 
                                    </td>
                                  </tr>
                                          
                                
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

@endsection
