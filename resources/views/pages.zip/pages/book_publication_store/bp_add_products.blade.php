@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
<div class="page-title">
    <div class="row">
    <div class="col-12 col-sm-6">
        <h3>অ্যাড নিউ প্রোডাক্ট / Add New Product</h3>
    </div>
    <div class="col-12 col-sm-6">

    </div>
    </div>
</div>
</div>

<!-- Container-fluid starts-->
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12">
    <div class="card">
        <div class="card-body">
        <form class="row g-3 needs-validation" action="{{route('g.store.all.products')}}"  >
            <div class="col-md-12 position-relative mb-4">
            <label class="form-label" for="validationTooltip01"> <span style="color: red">* </span> প্রোডাক্ট নাম</label>
            <input class="form-control" id="validationTooltip01" type="text" value="" required="">
            <div class="valid-tooltip">Looks good!</div>
            </div>
            <div class="col-md-4 position-relative mb-4">
            <label class="form-label" for="validationTooltip02">ইউনিট নেম / Unit Name</label>
            <input class="form-control image" id="image" type="text" value="" placeholder="Ex: pcs" required>
            <div class="valid-tooltip">Looks good!</div>
            </div>
            <div class="col-md-4 position-relative mb-4">
            <label class="form-label" for="validationTooltip02">ছবি(optional)</label>
            <input class="form-control image" id="image" type="file" value="">
            <div class="valid-tooltip">Looks good!</div>
            </div>
            <div class="col-md-4 position-relative mb-4 text-center">
            <img id="preview-image-before-upload" class="shadow rounded p-2" width="70%" src="https://static-01.daraz.com.bd/p/mdc/4cad5655443d69702d5c66d32428dbf6.jpg" >
            </div>
            
            <div class="col-md-6 position-relative mb-4">
                <label class="form-label" for="validationTooltip03">ইউনিট / Unit</label>
                <input class="form-control image" id="image" type="number" placeholder="Ex: 80" value="">
            </div>
            <div class="col-md-6 position-relative mb-4">
                <label class="form-label" for="validationTooltip03">বিস্তারিত / Description</label>
                <textarea class="form-control" id="validationTooltip03" type="text"></textarea>
            </div>
            
            
            <div class="col-12 text-right">
            <button class="btn btn-primary" type="submit">Submit</button>
            </div>
        </form>
        </div>
    </div>
    </div>
</div>
</div>
@endsection
