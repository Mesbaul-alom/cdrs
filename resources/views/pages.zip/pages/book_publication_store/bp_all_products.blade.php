@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>অল  প্রোডাক্ট / All Product</h3>
                </div>
                <div class="col-12 col-sm-6">

                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                          <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th scope="col">SI.</th>
                                  <th width="9%" scope="col">ছবি</th>
                                  <th width="40%" scope="col">প্রোডাক্ট নাম</th>
                                  <th scope="col">কারেন্ট স্টক</th>
                                  <th scope="col">আকশন</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row">1</th>
                                  <td><img width="100%" src="https://static-01.daraz.com.bd/p/b187013da2d8a455cf72e816105a2851.jpg" alt=""></td>
                                  <td>Urban District Stylish Curved Cap For men</td>
                                  <td>43 pcs</td>
                                   <td>
                                     <a href="#" class="btn btn-primary">এডিট</a> 
                                     <button class="btn btn-danger">ডিলিট </button>
                                   </td>
                                </tr>
                                <tr>
                                  <th scope="row">2</th>
                                  <td><img src="https://static-01.daraz.com.bd/p/2049f614574dd8aea2317aaadb4f03f0.jpg" width="100%" alt=""></td>
                                  <td>PU Leather styles long wallet for men with</td>
                                  <td>44 pcs</td>
                                  <td>
                                    <a href="#" class="btn btn-primary">এডিট</a> 
                                    <button class="btn btn-danger">ডিলিট </button>
                                  </td>
                                </tr>
                                <tr>
                                  <th scope="row">3</th>
                                  <td><img src="https://static-01.daraz.com.bd/p/25e6af03f267850b050c80c0f4092d4d.jpg_200x200q80-product.jpg_.webp" width="100%" alt=""></td>
                                  <td>LED Sensor Dream Mushroom Lamp - Multicolor</td>
                                  <td>84 pcs</td>
                                  <td>
                                    <a href="#" class="btn btn-primary">এডিট</a> 
                                    <button class="btn btn-danger">ডিলিট </button>
                                  </td>
                                </tr>
                                <tr>
                                    <th scope="row">4</th>
                                    <td><img width="100%" src="https://static-01.daraz.com.bd/p/b187013da2d8a455cf72e816105a2851.jpg" alt=""></td>
                                    <td>Urban District Stylish Curved Cap For men</td>
                                    <td>43 pcs</td>
                                     <td>
                                       <a href="#" class="btn btn-primary">এডিট</a> 
                                       <button class="btn btn-danger">ডিলিট </button>
                                     </td>
                                  </tr>
                                  <tr>
                                    <th scope="row">5</th>
                                    <td><img src="https://static-01.daraz.com.bd/p/mdc/b0ee3688a7deb36683e1c889a30812f3.png_200x200q80-product.jpg_.webp" width="100%" alt=""></td>
                                    <td>LED Sensor Dream Mushroom Lamp - Multicolor</td>
                                    <td>84 pcs</td>
                                    <td>
                                      <a href="#" class="btn btn-primary">এডিট</a> 
                                      <button class="btn btn-danger">ডিলিট </button>
                                    </td>
                                  </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

@endsection