@extends('layouts.app')
@section('body_content')

<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>সাপ্লায়ার / Supplier</h3>
                </div>
                <div class="col-12 col-sm-6">
                    <div class="text-right">
                        <button class="btn btn-info " type="button" data-bs-toggle="modal" data-original-title="test" data-bs-target="#exampleModal">অ্যাড নিউ সাপ্লায়ার / Supplier</button>
                    </div>
                
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header bg-dark">
                            <h5 class="modal-title text-light" id="exampleModalLabel">অ্যাড নিউ সাপ্লায়ার / Supplier</h5>
                            <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form method="POST" action="{{url('/admin/supplier/add')}}">
                            @csrf
                          <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                        <div class="form-group">
                                            <label for="example-text-input">Supplier Name</label>
                                            <input type="text" class="form-control" id="" required="" name="name">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="example-text-input">Supplier Email</label>
                                            <input type="text" class="form-control" id="" required="" name="email">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-group">
                                            <label for="example-text-input">Supplier Phone Number</label>
                                            <input type="text" class="form-control" maxlength="11" minlength="11" required="" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <div class="form-group">
                                            <label for="example-text-input">Company Name</label>
                                            <input type="text" class="form-control"  required="" name="company_name">
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Close</button>
                            <button class="btn btn-success" type="submit">Add</button>
                          </div>
                        </form>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
             
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                            <div class="table-responsive">
                                <table width="100%" class="table">
                                    <thead>
                                        <tr>
                                            <th>SI</th>
                                            <th width="25%">Supplier Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Company</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @php
                                      $sl=1;
                                        @endphp
                                    
                                             @foreach ($suppliers as $supplier)
                                               
                                             <tr>                                                                                                            <tr>
                                            <td>{{$sl++}}</td>
                                            <td>{{$supplier->supplier_name}}</td>
                                            <td>{{$supplier->email}}</td>
                                            <td>{{$supplier->phone}}</td>
                                            <td>{{$supplier->company_name}}</td>
                                           <td width="30%">
                                        <a type="button"href="/supplier/edit/{{$supplier->id}}" class="btn btn-sm btn-info js-tooltip-enabled" ><i class="fa fa-fw fa-pencil-alt"></i> Edit</a>
                                     
                                     @if ($supplier->is_active == 1)
                                     <a type="button"href="/supplier/deactive/{{$supplier->id}}" class="btn btn-sm btn-success js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="CRM is active now, click to deactive">Active</a>
                                    @else
                                    <a type="button"href="/supplier/active/{{$supplier->id}}" class="btn btn-sm btn-danger js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="CRM is active now, click to deactive">Deactive</a>
                                     @endif
                                       

            
                                            </td>
                                        </tr>
                                        @endforeach
                                               </tbody>
                                </table>
                            </div>
                          
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
@endsection
