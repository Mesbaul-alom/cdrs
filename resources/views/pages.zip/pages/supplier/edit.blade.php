@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3> সাপ্লায়ার  এডিট  / Supplier Edit</h3>
                </div>
                <div class="col-12 col-sm-6">

                </div>
              </div>
            </div>
          </div>

          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-body">
                    <form class="row g-3 needs-validation" action="{{route('supplier.update')}}" method="post" >
                        @csrf
                        <input type="hidden" name="id" value="{{$supplier->id}}">
                      <div class="col-md-6 position-relative mb-4">
                        <label class="form-label" for="validationTooltip01"> <span style="color: red">* </span> নাম</label>
                        <input class="form-control" id="validationTooltip01" name="supplier_name" type="text" value="{{$supplier->supplier_name}}" required="">
                        
                      </div>
                      <div class="col-md-6 position-relative mb-4">
                        <label class="form-label" for="validationTooltip02">ইমেইল  / Email</label>
                        <input class="form-control" id="validationTooltip01" name="email" type="email" value="{{$supplier->email}}" required="">
                      </div>
                       <div class="col-md-6 position-relative mb-4">
                        <label class="form-label" for="validationTooltip02">ফোন /Phone</label>
                        <input class="form-control" id="validationTooltip01" name="phone" type="number" value="{{$supplier->phone}}" required="">
                        <div class="valid-tooltip">Looks good!</div>
                      </div>
                       
                      <div class="col-md-6 position-relative mb-4">
                        <label class="form-label" for="validationTooltip03">কোম্পানির নাম / Company Name</label>
                        <input class="form-control" id="validationTooltip01" name="company_name" type="text" value="{{$supplier->company_name}}" required="">
                      </div>
                     
                      <div class="col-12 text-right">
                        <button class="btn btn-primary" type="submit">আপডেট </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
@endsection
