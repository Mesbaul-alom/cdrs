<!DOCTYPE html>
<html lang="en"> 
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/icofont.css')}}">
    <!-- Themify icon-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/themify.css')}}">
    <!-- Flag icon-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/flag-icon.css')}}">
    <!-- Feather icon-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/feather-icon.css')}}">
    <!-- Plugins css start-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/scrollbar.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/animate.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/date-picker.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/photoswipe.css')}}">
    <!-- Plugins css Ends-->
    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/vendors/bootstrap.css')}}">
    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/new_css.css')}}">
    
    <link id="color" rel="stylesheet" href="{{asset('backend/assets/css/color-1.css')}}" media="screen">
    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="{{asset('backend/assets/css/responsive.css')}}">

    <link rel="stylesheet" type="text/css" href="{{ asset('css/toastify.min.css') }}">

  </head>
  <body>     

  

      
      <!-- Page Header Ends                              -->
      <!-- Page Body Start-->
      <div class="container">
      
        


        <!-- Page Sidebar Ends-->
        <div class="page-body">

            <div class="container-fluid">
                <div class="page-title">
                  <div class="row">
                    <div class="col-12 col-sm-12">
                        @php
                        $logo=\App\Models\BusinessSetting::latest()->get()->first();
                     
                      @endphp
                    <div class="logo-wrapper text-center border-bottom" style="padding: 3px 20px !important;"><a href="{{route('/')}}"><img class="img-fluid for-light" style="height: 70px !important;" src="{{asset($logo->logo)}}" alt=""><img class="img-fluid for-dark" style="height: 70px !important;" src="{{asset('backend/assets/image/logom.png')}}" alt=""></a>
                    <div class="back-btn"><i class="fa fa-angle-left"></i></div>
                    </div>
                                        </div>
                                        
                                    </div>
                                    </div>
                                </div>

                        <!-- Container-fluid starts-->
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                            <div class="card" style="width: 100%;">
                                
                                <div class="card-body">
                                    
                                            
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <h6 class="text-success"><b>Supplier Info,</b></h6>
                                                            <p class="card-text"><b>Name:</b>{{$data->supplier->supplier_name}}<br><b>Phone:</b> {{$data->supplier->phone}}<br><b>Company Name:</b> {{$data->supplier->company_name}}</p>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <p class="card-text" style="color: #fe8800; text-align:right;"><b>Invoice # </b> {{$data->invoice_number}}<br><b>Date:</b> {{date('d-m-Y', strtotime($data->date))}}</p>
                                                    </div>
                                                </div>
                                        
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <table class="table table-sm table-bordered">
                      <thead>
                        <tr>
                          <th width="5%" scope="col">SN</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">Quantity</th>
                        </tr>
                      </thead>
                      <tbody>
                        @php
                        $sl=1;
                      @endphp
                      @foreach ($products  as $product )
                      <tr>
                        <th scope="row">{{$sl++}}</th>
                        @php
                          $produc=\App\Models\Genarel_store_product::Find($product->product_id);
                        $product_name=  $produc->product_title;
                        @endphp
                        <td>{{ $product_name}}</td>
                        <td>{{$product->qty}} pcs</td>
                      </tr>
                      @endforeach
                     
                     
                                                    
                     </tbody>
                    </table>
                 </div>
            </div>
            
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <p><b>*নোট / Note:</b><br>
                      {{$data->note}}
                    </p>
                </div>
                <div class="col-md-12">
                         
            </div>
          </div>
            
        </div>
    </div>
    <!-- /.row (main row) -->
  </div><!-- /.container-fluid -->
        </div>
        
    </div>
  </div>
        </div>

       
        </div>
      </div>
      <!-- latest jquery-->
      <script src="{{asset('backend/assets/js/jquery-3.5.1.min.js')}}"></script>
      <!-- Bootstrap js-->
      <script src="{{asset('backend/assets/js/bootstrap/bootstrap.bundle.min.js')}}"></script>
      <!-- feather icon js-->
      <script src="{{asset('backend/assets/js/icons/feather-icon/feather.min.js')}}"></script>
      <script src="{{asset('backend/assets/js/icons/feather-icon/feather-icon.js')}}"></script>
      <!-- scrollbar js-->
      <script src="{{asset('backend/assets/js/scrollbar/simplebar.js')}}"></script>
      <script src="{{asset('backend/assets/js/scrollbar/custom.js')}}"></script>
      <!-- Sidebar jquery-->
      <script src="{{asset('backend/assets/js/config.js')}}"></script>
      <!-- Plugins JS start-->
      <script src="{{asset('backend/assets/js/sidebar-menu.js')}}"></script>
      <script src="{{asset('backend/assets/js/chart/knob/knob.min.js')}}"></script>
      <script src="{{asset('backend/assets/js/chart/knob/knob-chart.js')}}"></script>
      <script src="{{asset('backend/assets/js/chart/apex-chart/apex-chart.js')}}"></script>
      <script src="{{asset('backend/assets/js/chart/apex-chart/stock-prices.js')}}"></script>
      <!-- <script src="../assets/js/notify/bootstrap-notify.min.js"></script> -->
      <script src="{{asset('backend/assets/js/dashboard/default.js')}}"></script>
      <script src="{{asset('backend/assets/js/notify/index.js')}}"></script>
      <script src="{{asset('backend/assets/js/datepicker/date-picker/datepicker.js')}}"></script>
      <script src="{{asset('backend/assets/js/datepicker/date-picker/datepicker.en.js')}}"></script>
      <script src="{{asset('backend/assets/js/datepicker/date-picker/datepicker.custom.js')}}"></script>
      <script src="{{asset('backend/assets/js/photoswipe/photoswipe.min.js')}}"></script>
      <script src="{{asset('backend/assets/js/photoswipe/photoswipe-ui-default.min.js')}}"></script>
      <script src="{{asset('backend/assets/js/photoswipe/photoswipe.js')}}"></script>
      <script src="{{asset('backend/assets/js/typeahead/handlebars.js')}}"></script>
      <script src="{{asset('backend/assets/js/typeahead/typeahead.bundle.js')}}"></script>
      <script src="{{asset('backend/assets/js/typeahead/typeahead.custom.js')}}"></script>
      <script src="{{asset('backend/assets/js/typeahead-search/handlebars.js')}}"></script>
      <script src="{{asset('backend/assets/js/typeahead-search/typeahead-custom.js')}}"></script>
      <script src="{{asset('backend/assets/js/height-equal.js')}}"></script>
      <script src="{{asset('backend/assets/js/fontawesome.js')}}"></script>
      <script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
  
      <script src="{{ asset('js/toastify-js.js') }}"></script>
      
      <!-- Plugins JS Ends-->
      <!-- Theme js-->
      <script src="{{asset('backend/assets/js/script.js')}}"></script>
      <!-- <script src="../assets/js/theme-customizer/customizer.js"></script> -->
      <!-- login js-->
      <!-- Plugin used-->
  
    </body>
  
  
  <script>
     function success(message) {
          Toastify({
                  text: message,
                  gravity: "bottom",
                  position: "left",
                  backgroundColor: "linear-gradient(to right, #269E70, #269E70)",
                  className: "error",
              }).showToast();
          }
  
          function error(message) {
          Toastify({
                  text: message,
                  gravity: "bottom",
                  position: "left",
                  backgroundColor: "linear-gradient(to right, #F93C0A, #FF3551)",
                  className: "error",
              }).showToast();
          }
  
  </script>
  
  


       
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" crossorigin="anonymous"
          referrerpolicy="no-referrer"></script>
      
      <script>
      $(document).ready(function () {
          window.print();
      });
      
         </script> 
  </html>
