@extends('layouts.app')
@section('body_content')
<div class="container-fluid">        
    <div class="page-title">
        <div class="row">
        <div class="col-12 col-sm-6">
            <h3>ফিল্ম এন্ড লাইব্রেরী ড্যাশবোর্ড</h3>
        </div>
        <div class="col-12 col-sm-6">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"> <a class="home-item" href="{{route('/')}}"><i data-feather="home"></i></a></li>
            </ol>
        </div>
        </div>
    </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid default-dash">
    <div class="row"> 
        
    <div class="col-xl-4 col-md-6 dash-31 dash-xl-50">
        <div class="card news-update">
            <div class="card-header card-no-border "> 
            <div class="header-top border-bottom">
                <h5 class="m-0">Recent Refundable Products</h5>
            </div>
            <div class="card-body pt-0">           
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Invoice Number</th>
                        <th>Refund Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                    <tr>
                        <td>Sohel Mia</td>
                        
                        <td>S/232</td>
                        <td>31-05-2-22</td>
                    </tr>
                      
                    </tbody>
                </table>
                </div>
            </div>
        </div>
        </div>
        </div>


        <div class="col-xl-3 col-md-6 dash-xl-50">
        <div class="card weekly-column">
            <div class="card-body p-0">
            <div id="weekly-chart"> </div>
            </div>
        </div>
        </div>
        
        
        <div class="col-xl-6 col-lg-12 dash-xl-100">
        <div class="card total-transactions">
            <div class="row m-0">
            <div class="col-md-6 col-sm-6 p-0">
                <div class="card-header card-no-border">
                <h5>Total Transactions</h5>
                </div>
                <div class="card-body pt-0">
                <div> 
                    <div id="transaction-chart"></div>
                </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 p-0 report-sec">
                <div class="card-header card-no-border"> 
                <div class="header-top">
                    <h5 class="m-0">Report</h5>
                    <div class="icon-box onhover-dropdown"><i data-feather="more-horizontal"></i>
                    <div class="icon-box-show onhover-show-div">
                        <ul> 
                        <li> <a>
                                Today</a></li>
                        <li> <a>
                                Yesterday</a></li>
                        <li> <a>
                                Tommorow</a></li>
                        </ul>
                    </div>
                    </div>
                </div>
                </div>
                <div class="card-body pt-0">
                <div class="row"> 
                    <div class="col-6 report-main">
                    <div class="report-content text-center"> 
                        <p class="font-theme-light">This Week</p>
                        <h5>+86.53%</h5>
                        <div class="progress progress-round-primary">
                        <div class="progress-bar" role="progressbar" style="width: 45%" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    </div>
                    <div class="col-6">
                    <div class="report-content text-center"> 
                        <p class="font-theme-light">Last Week</p>
                        <h5>-34.50%</h5>
                        <div class="progress progress-round-secondary">
                        <div class="progress-bar" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    </div>
                    <div class="col-12">        
                    <div class="media report-perfom">
                        <div class="media-body">
                        <p class="font-theme-light">Performance </p>
                        <h5 class="m-0">+93.82%</h5>
                        </div><a class="btn btn-primary" href="blog-single.html">New Report</a>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        
        
    </div>
    </div>
    <!-- Container-fluid Ends-->
@endsection

