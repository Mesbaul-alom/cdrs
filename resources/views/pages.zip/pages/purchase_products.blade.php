@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-12">
                  <h3>General Stock Product Purchase / ক্রয়</h3>
                </div>
                <div class="col-12 col-sm-6">

                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <form action="{{route('g.store.purchase.product.store')}}" method="post">
              @csrf
            <div class="row">
              <div class="col-sm-8">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                          <div class="table-responsive" >
                            <table class="table" >
                              <thead>
                                <tr>
                                  <th  scope="col">IMAGE</th>
                                  <th scope="col">PRODUCT NAME</th>
                                  <th scope="col">PRODUCT STOCK</th>
                                  <th  scope="col">Add QUANTITY</th>
                                  
                                </tr>
                              </thead>
                              <tbody id="demo">
                               
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="card recent-activity">
                    <div class="card-header card-no-border bg-dark text-light">
                        <div class="media media-dashboard">
                            <div class="media-body"> 
                            <h5>Search Products</h5>
                            </div>
                        </div>
                        <br>
                        <input type="text" class="form-control" id="search_purchase_product" placeholder="Search....">
                    </div>
                </div>

               <div class="card" style="display: none" id="show1">
                <div class="card-body">
                  <div class="table-responsive" id="search_product">
                  
                  </div>
                </div>
               </div>
                
                <div class="card recent-activity">
                    <div class="card-header card-no-border">
                    <div class="media media-dashboard border-bottom">
                        <div class="media-body"> 
                        <h5> Search Supplier</h5>
                        <hr>
                        <input type="text" class="form-control" id="search_supplier" placeholder="Search....">
                        </div>
                    </div>
                    </div>
                </div>
                <div class="card" style="display: none" id="show2" >
                  <div class="card-body">
                    <div class="table-responsive" id="search_supplier_show">
                    
                    </div>
                  </div>
                 </div>
              </div>
              <div class="col-sm-6">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block">
                      <div class="col-md-12 position-relative mb-4">
                       <h3>Supplier Info.</h3>
                      </div>
                        <div class="col-md-12 position-relative mb-4">
                            <label class="form-label" for="validationTooltip03"> Supplier Name</label>
                            <input class="form-control" type="hidden" name="s_id" id="s_id">
                            <input class="form-control" type="text" name="s_name"  id="s_name" readonly >
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-check-label"><b>Phone</b></label>
                                <input class="form-control" type="text" name="s_phone" id="s_phone" readonly required>
                            </div>
                        </div>
                          <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-check-label"><b>Company Name</b></label>
                                <input class="form-control" type="text" name="s_company" id="s_company" readonly >
                            </div>
                        </div>
                       
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="card">
                  <div class="card-body">
                    <div class="card-block">
                        <div class="col-md-12 position-relative mb-4">
                            <label class="form-label" for="validationTooltip03">নোট / Note</label>
                            <textarea class="form-control" name="note" id="" cols="30" rows="4"></textarea>
                          </div>
                          <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-check-label"><b>Date</b></label>
                                    <input class="form-control" type="date" name="date" id="InvDate" value="2022-05-31" required="">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="form-check-label"><b>Voucher Num.</b></label>
                                    <input class="form-control" type="text" name="supp_voucher_num" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group text-right mt-3">
                            <button class="btn btn-primary" type="submit">Submit</button>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </form>
          </div>




          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" crossorigin="anonymous"
    referrerpolicy="no-referrer"></script>
<script>
      $('#search_purchase_product').keyup(function () {
        var info = $(this).val();
        console.log(info);
        $.ajax({
            type: 'get',
            url: '/general-store/purchse-products/search',
            data: {
                'info': info,
            },
            success: function (data) {
              $("#show1").show();
                $('#search_product').html(data);
                
            }
        });
    });
    // End:: Customer Search for stock in 
      $('#search_supplier').keyup(function () {
        var info = $(this).val();
        console.log(info);
        $.ajax({
            type: 'get',
            url: '/general-store/supplier/search',
            data: {
                'info': info,
            },
            success: function (data) {
              console.log(data);
              $("#show2").show();
                $('#search_supplier_show').html(data);
                
            }
        });
    });
    // End:: Customer Search for stock in 


    function add_product_data(name, id, image, stock_unit) {
         var i=1;
        
        if($('#check_id_'+id).val()) {
            Toastify({
                text: name+ " Is Exist Into Tabel Item.",
                backgroundColor: "linear-gradient(to right, #F50057, #2F2E41)",
                className: "error",
            }).showToast();
        }
        else {
           
             i++;  
            $('#demo').append('<tr id="row'+id+'" class="dynamic-added" style="background-color:#F2F2F2;color: #000;"><td><input type="hidden" id="check_id_'+id+'" value="'+id+'"><input type="hidden"  name="id[]" value="'+id+'"><strong>mesba</strong></td><td><strong class="pd-name">'+name+'</strong></td></td><td><strong class="pd-name">'+stock_unit+'</strong></td><td><input type="number" id="amount" class="amount" name="qty[]" required><td><button type="button" name="remove" id="'+id+'" class="btn btn-danger btn_remove amount">X</button></td></tr>');
            $("#show1").hide();
          }  
    }
    function add_supplier_data(name, id, phone, company_name) {
       
       
             $('#s_name').val(name);
             $('#s_phone').val(phone);
             $('#s_company').val(company_name);
             $('#s_id').val(id);
             $("#show2").hide();
       
    }

    $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id"); 
           $('#row'+button_id+'').remove();  
           sum();
      }); 

</script>

@endsection
