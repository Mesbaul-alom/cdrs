@extends('layouts.app')
@section('body_content')

<div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-12">
                  <h3>বিতরণকারী / Distributor</h3>
                </div>
                
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row">
              <div class="col-sm-12">
             
                <div class="card">
                  <div class="card-body">
                    <div class="card-block row">
                        <div class="col-sm-12 col-lg-12 col-xl-12">
                            <div class="table-responsive">
                                <table width="100%" class="table table-bordered table-striped table-vcenter">
                                    <thead>
                                        <tr>
                                            <th>SI</th>
                                            <th width="25%">CRM Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                                                                                                                                                <tr>
                                            <td>1</td>
                                            <td>sohel</td>
                                            <td>sohel@gmail.com</td>
                                            <td>95858588558</td>
                                            <td width="30%">
                                                
                                                <a type="button" href="#" class="btn btn-sm btn-warning">View Report</a>

                                                
                                            </td>
                                        </tr>
                                                                                                                                                                <tr>
                                            <td>2</td>
                                            <td>Fahad</td>
                                            <td>sohel@gmail.com</td>
                                            <td>54722222222</td>
                                            <td width="30%">
                                                
                                                <a type="button" href="#" class="btn btn-sm btn-warning">View Report</a>

                                                
                                            </td>
                                        </tr>
                                                                                                                                                                <tr>
                                            <td>3</td>
                                            <td>Abul Kashem</td>
                                            <td>sohel@gmail.com</td>
                                            <td>01236447886</td>
                                            <td width="30%">
                                                
                                                                                                    <a type="button" href="#" class="btn btn-sm btn-warning">View Report</a>

                                                
                                            </td>
                                        </tr>
                                                                                                                    </tbody>
                                </table>
                            </div>
                          
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
@endsection
