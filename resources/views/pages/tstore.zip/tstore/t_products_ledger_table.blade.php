@extends('layouts.app')
@section('body_content')
<div class="container-fluid">
<div class="page-title">
    <div class="row">
        <div class="col-12 col-sm-6">
            <h3>প্রোডাক্ট লেজার টেবিল</h3>
        </div>
    </div>
</div>
</div>
<!-- Container-fluid starts-->
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12">
    <div class="card">
        <div class="card-body">
        <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">SN.</th>
                            <th width="25%" scope="col">Product Info</th>
                            <th scope="col">Returned</th>
                            <th scope="col">Distribute</th>
                            <th width="30%" class="text-center" scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                            <td>1</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td><h5>Folate Tablet,   5 mg,</h5></td>
                            <td>19 piece</td>
                            <td> 12 piece </td>
                            <td class="text-center"><a class="btn btn-success btn-sm" href="#">View Distribute Info</a></td>
                        </tr>
                        
                                                                                                                        
                        
                    </tbody>
                    </table>
        </div>
    </div>
    </div>
</div>
</div>
@endsection
