<?php

namespace App\Http\Controllers\TechnicalController;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class TechnicalStoreRefundController extends Controller
{
    //
}
