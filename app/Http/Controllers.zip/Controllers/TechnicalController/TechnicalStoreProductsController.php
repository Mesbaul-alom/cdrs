<?php

namespace App\Http\Controllers\TechnicalController;
use App\Http\Controllers\Controller;
use App\Models\Technical_store_products;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\Auth;
class TechnicalStoreProductsController extends Controller
{
    public function productstore(Request $request){
 
        $randomNumber = random_int(100, 999);
        $code="GS".$randomNumber;
        $product=new Technical_store_products;
        
          $product->code =$code;	
        $product->product_title	= $request->name;
        $product->unit_name	=$request->unit;
        $product->description	=$request->description;
        $product->stock_unit = $request->qty;
        $product->distributed_unit = 0;
       if ($request->image) {
        $imageName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images'), $imageName);
        $product->image	=$imageName;
       }
         $product->save();
    
         return redirect('/technical-store/products/list')->with('success','product  add successfully');
    
      }



      public function all_products() {
        $wing = 'g_store';
$products=Technical_store_products::all();
        return view('pages.tstore.product.all_products', compact('wing','products'));
    }

    public function product_list_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data = Technical_store_products::latest()->get();
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= '<a type="button"  href="'.route('t.store.product.edit', $row->id).'"  class="btn btn-success btn-sm rounded-pill" ><i class="fas fa-edit"></i></a><a type="button"  href="'.route('g.store.product.details', $row->id).'" class="btn btn-primary btn-sm rounded-pill" ><i class="fas fa-eye"></i></a> ';   
                return $info;
            })
                ->addColumn('image', function($row){
            return '<img src="'.asset('/images/'.optional($row)->image).'" style="width: 50px;" class="rounded" >';
        })
            ->addColumn('name', function($row){
                
                return optional($row)->product_title;
            })
            ->addColumn('distributionstock', function($row){
                return optional($row)->distributed_unit  ; 
            })
            ->addColumn('currentstock', function($row){
                return optional($row)->stock_unit ; 
            })
            ->rawColumns(['action','image','name','distributionstock','currentstock'])
                    ->make(true);
        }
      
      
    }
    public function product_edit($id){
        $wing = 'g_store';
    $product=Technical_store_products::find($id);
    return view('pages.tstore.product.edit',compact('product','wing'));
    
      } 

      public function productupdate(Request $request){
        $product=Technical_store_products::find($request->id);
        $product->product_title	= $request->name;
        $product->unit_name	=$request->unit;
        $product->stock_unit	+=$request->new_stock_unit;
        $product->description	=$request->description;
        // $product->stock_unit = $request->qty;
        if ($request->image) {
          $imageName = time().'.'.$request->image->extension();  
        $request->image->move(public_path('images'), $imageName);
        $product->image	=$imageName;
        }
        
         $product->save();
      
         return redirect('/technical-store/products/list')->with('success','product  add successfully');
      }




      public function t_current_stock_products() {
        $wing = 't_store';
        return view('pages.tstore.product.current_stock_products', compact('wing'));
    }
}
