<?php
namespace App\Http\Controllers\TechnicalController;
use App\Http\Controllers\Controller;
use DataTables;
use Illuminate\Support\Facades\Auth;
use App\Models\Technical_store_products;
use App\Models\Technical_store_distributed_products;
use App\Models\Technical_store_distribution;
use App\Models\Technical_store_distributor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use PDF;
class TechnicalStoreDistributionController extends Controller
{
    public function t_sold_products() {
        $wing = 't_store';
        return view('pages.tstore.distribution.sold_products', compact('wing'));
    }


    public function purchase_products_search(Request $request){

        $info = $request->info;
        $output = '';
        
        if(!empty($info)) {
             
            $info = DB::table('Technical_store_products')
                    ->Where(function ($query) use ($info) {
                        $query->where('product_title', 'LIKE', '%'. $info. '%');
                    })
                    ->limit(15)
                    ->get();
    
            if(count($info) > 0) {
                $output .= '<table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Action</th>
                                        <th scope="col"> Name</th>
                                    </tr>
                                </thead>
                                <tbody>';
                                foreach ($info as $item) {
                                    
                                    $output.='<tr>'.
                                    '<td><button type="button" onclick="add_product_data(\''.$item->product_title.'\',\''.$item->id.'\',\''.$item->image.'\',\''.$item->stock_unit.'\')" class="btn btn-primary btn-sm btn-rounded">+</button></td>'.
                                    '<td>
                                 ' .$item->product_title.'
                                    </td>'.
                                        
                                        
                                        '</tr>';
                                    }
                                $output .= '</tbody>
                            </table>';
    
            }
            else {
                $output.='<h2 class="text-center">No Result Found</h2>';
            }
        }
        return Response($output);
    
       }



       public function distributor_search(Request $request){

        $info = $request->info;
        $output = '';
        
        if(!empty($info)) {
             
            $info = DB::table('technical_store_distributors')
                    ->Where(function ($query) use ($info) {
                        $query->where('phone', 'LIKE', '%'. $info. '%');
                    })
                    ->orWhere(function ($query) use ($info) {
                        $query->where('distributor_name', 'LIKE', '%'. $info. '%');
                    })
                    ->limit(15)
                    ->get();
    
            if(count($info) > 0) {
                $output .= '<table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Action</th>
                                        <th scope="col">Distributor</th>
                                    </tr>  
                                </thead>
                                <tbody>';
                                foreach ($info as $item) {
                                    
                                    $output.='<tr>'.
                                    '<td><button type="button" onclick="add_distributor_data(\''.$item->distributor_name.'\',\''.$item->id.'\',\''.$item->phone.'\',\''.$item->address.'\')" class="btn btn-primary btn-sm btn-rounded">+</button></td>'.
                                    '<td>
                                 ' .$item->distributor_name.'
                                 ' .$item->phone.'
                                    </td>'.
                                        
                                        
                                        '</tr>';
                                    }
                                $output .= '</tbody>
                            </table>';
    
            }
            else {
                $output.='<h2 class="text-center">No Result Found</h2>';
            }
        }
        return Response($output);
    
       }







       public function sold_store(Request $request){
        if ($request->d_id) {
            $invoice= rand(1000, 9999);
            $invoice_number="d".$invoice;
            $user=Auth::user()->id;
            DB::table('technical_store_distributions')->insert(
                [
           'distributor_id'=>$request->d_id,
        //    'product_id'=>$request->id[$key],
        //     'qty'=>$request->id[$key],
            'invoice_number'=>$invoice_number,
            'refund_date'=>$request->refunddate,
            'date'=>$request->date,
            'note'=>$request->note,
            'user_id'=>$user,
        ]);
        
             foreach ($request->id  as $key => $id) {
                
                DB::table('technical_store_distributed_products')->insert(
                    
                    [
                    'distributor_id'=>$request->d_id,
                    'product_id'=>$request->id[$key],
                    'qty'=>$request->qty[$key],
                    'invoice_number'=>$invoice_number,
            ]);
           
            $product=Technical_store_products::Find($request->id[$key]);
            $product->stock_unit -=$request->qty[$key];
            $product->save();
            }
            $data =Technical_store_distribution::with('distributor')->where('invoice_number',$invoice_number)->get()->first();
            $id= $data->id;
        $products=Technical_store_distributed_products::where('invoice_number',$data->invoice_number)->get();
            $wing = 't_store';
            return Redirect()->route('t.store.sold.invoices.view', $id);
            // return view('pages.tstore.distribution.sold_invoices_view', compact('wing','data','products','id'));
            }else{
                $check=Technical_store_distributor::where('phone',$request->phone)->get()->first();
                if ($check == null) {
                    $distributor=new Technical_store_distributor;
                    $distributor->distributor_name=$request->name;
                    $distributor->phone=$request->phone;
                    $distributor->address=$request->address;
                    $distributor->save();
                
                    $product=Technical_store_distributor::where('phone',$request->phone)->get()->first();
                    $d_id=$product->id;
                  
                    $invoice= rand(1000, 9999);
                    $invoice_number="d".$invoice;
                    $user=Auth::user()->id;
                   
                    DB::table('technical_store_distributions')->insert(
                        [
                   'distributor_id'=>$d_id,
                //    'product_id'=>$request->id[$key],
                'refund_date'=>$request->refunddate,
                    'invoice_number'=>$invoice_number,
                    'date'=>$request->date,
                    'note'=>$request->note,
                    'user_id'=>$user,
                ]);
                
                     foreach ($request->id  as $key => $id) {
                        DB::table('technical_store_distributed_products')->insert(
                            [
                            'distributor_id'=>$d_id,
                            'product_id'=>$request->id[$key],
                            'qty'=>$request->qty[$key],
                            'invoice_number'=>$invoice_number,
                    ]);
                    $product=Technical_store_products::Find($request->id[$key]);
                    $product->stock_unit -=$request->qty[$key];
                    $product->save();
                    }
                    $data =Technical_store_distribution::with('distributor')->where('invoice_number',$invoice_number)->get()->first();
                    $id= $data->id;
                    $products=Technical_store_distributed_products::where('invoice_number',$data->invoice_number)->get();
                    $wing = 't_store';
                    return Redirect()->route('t.store.sold.invoices.view', $id);
                    // return view('pages.tstore.distribution.sold_invoices_view', compact('wing','data','products','id'));
                }else{
                    return back()->with('error','Already this distributor add!');;
                }
            
        }
           }


           public function sold_invoices_print($id) {
            $data =Technical_store_distribution::with('distributor')->where('id',$id)->get()->first();
            $products=Technical_store_distributed_products::where('invoice_number',$data->invoice_number)->get();
            $wing = 'g_store';
            $pdf = PDF::loadView('pages.tstore.distribution.sold_invoices_print', compact('data','products'));
            return $pdf->stream('pages.tstore.distribution.sold_invoices_print');
            
        }




        public function t_sold_invoices() {
            $wing = 't_store';
            return view('pages.tstore.distribution.sold_invoices', compact('wing'));
        }



        public function distributor_list_index(Request $request)
        {
       
            if ($request->ajax()) {
                $data =Technical_store_distribution::with('distributor')->latest()->get();
                return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $info = '';
                   
                            $info .= '<a type="button" href="'.route('t.store.sold.invoices.view', $row->id).'" class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
                    return $info;
                })
                ->addColumn('day', function($row){
                     
                      return date('d-m-Y', strtotime($row->date));
                })
                ->addColumn('customerName', function($row){
                     
                      return optional($row)->distributor->distributor_name;
                })
                ->addColumn('phone', function($row){
                     
                    return optional($row)->distributor->phone;
                })
                ->addColumn('address', function($row){
                     
                    return optional($row)->distributor->address;
                })
                ->addColumn('invoicenumber', function($row){
                    return optional($row)->invoice_number; 
                })
               
                ->rawColumns(['action','day','customerName', 'phone','address','invoicenumber'])
                        ->make(true);
            }
          
            
        }




        public function sold_invoices_view($id) {
            $data =Technical_store_distribution::with('distributor')->where('id',$id)->get()->first();
            $products=Technical_store_distributed_products::where('invoice_number',$data->invoice_number)->get();
            $wing = 't_store';
            return view('pages.tstore.distribution.sold_invoices_view', compact('wing','data','products','id'));
        }

}
