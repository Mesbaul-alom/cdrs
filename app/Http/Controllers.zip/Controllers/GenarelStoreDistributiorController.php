<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Genarel_store_distributior;
use App\Models\Genarel_store_distribution_product;
use App\Models\Genarel_store_purchase;
class GenarelStoreDistributiorController extends Controller
{
    public function distributor_report_view($id){
        $products=Genarel_store_distribution_product::where('distributor_id',$id)->get();
        $wing = 'g_store';
        return view('pages.distribution_report', compact('wing','products'));
    }
}
