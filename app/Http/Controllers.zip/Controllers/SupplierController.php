<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Supplier;
class SupplierController extends Controller
{

    public function suppliers() {
        $wing = 'g_store';
        $suppliers=Supplier::all();
        return view('pages.supplier.suppliers', compact('wing','suppliers'));
    }
    public function supplieredit($id) {
        $wing = 'g_store';
        $supplier=Supplier::find($id);
        return view('pages.supplier.edit', compact('wing','supplier'));
    }
    public function supplieadd(Request $request){
       
        $supplier = new Supplier;
        $supplier->supplier_name=$request->name;
        $supplier->email=$request->email;
        $supplier->phone=$request->phone;
        $supplier->company_name=$request->company_name;
        $supplier->save();

        return back()->with('success', 'New Supplier Add Successfully Done');

    }
    public function supplierupdate(Request $request){
       
        $supplier=Supplier::find($request->id);
        $supplier->supplier_name=$request->supplier_name;
        $supplier->email=$request->email;
        $supplier->phone=$request->phone;
        $supplier->company_name=$request->company_name;
        $supplier->save();

        return redirect('/general-store/suppliers')->with('success', 'Update Supplier  Successfully Done');

    }
    public function supplierdeactive($id){
       
        $supplier=Supplier::find($id);
        $supplier->is_active=0;
        $supplier->save();

        return back()->with('success', 'Supplier Deactive Successfully Done');

    }
    public function supplieractive($id){
       
        $supplier=Supplier::find($id);
        $supplier->is_active=1;
        $supplier->save();

        return back()->with('success', ' Supplier Active Successfully Done');

    }
}
