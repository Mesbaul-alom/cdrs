<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Genarel_store_product;
use App\Models\Genarel_store_purchase;
use App\Models\Genarel_store_purchase_product;
class GenarelStorePurchaseProductController extends Controller
{
    public function product_purchase_store(Request $request){
        $invoice= rand(1000, 9999);
        $invoice_number="p".$invoice;
        $user=Auth::user()->id;
        DB::table('genarel_store_purchases')->insert(
            [
       'supplier_id'=>$request->s_id,
    //    'product_id'=>$request->id[$key],
    //     'qty'=>$request->id[$key],
        'invoice_number'=>$invoice_number,
        'voucher_number'=>$request->supp_voucher_num,
        'date'=>$request->date,
        'note'=>$request->note,
        'user_id'=>$user,
    ]);
         foreach ($request->id  as $key => $id) {
            DB::table('genarel_store_purchase_products')->insert(
                [
           'supplier_id'=>$request->s_id,
          'product_id'=>$request->id[$key],
         'qty'=>$request->qty[$key],
            'invoice_number'=>$invoice_number,
            'date'=>$request->date,
           
        ]);
        $product=Genarel_store_product::Find($request->id[$key]);
        $product->stock_unit +=$request->qty[$key];
        $product->save();
        }
        $data = Genarel_store_purchase::with('supplier')->where('invoice_number',$invoice_number)->get()->first();
        $id=$data->id;
        $products=Genarel_store_purchase_product::where('invoice_number',$data->invoice_number)->get();
        $wing = 'g_store';
 return view('pages.purchase_invoices_view',compact('data','wing','products','id'));
    }
}

