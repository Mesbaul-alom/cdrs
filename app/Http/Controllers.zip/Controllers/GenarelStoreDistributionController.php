<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Genarel_store_distributior;
use App\Models\Genarel_store_distribution_product;
use App\Models\Genarel_store_distribution;
use App\Models\Genarel_store_purchase;
use App\Models\Genarel_store_product;
class GenarelStoreDistributionController extends Controller
{
   public function sold_store(Request $request){
if ($request->d_id) {
    $invoice= rand(1000, 9999);
    $invoice_number="d".$invoice;
    $user=Auth::user()->id;
    DB::table('genarel_store_distributions')->insert(
        [
   'distributor_id'=>$request->d_id,
//    'product_id'=>$request->id[$key],
//     'qty'=>$request->id[$key],
    'invoice_number'=>$invoice_number,
    'date'=>$request->date,
    'note'=>$request->note,
    'user_id'=>$user,
]);

     foreach ($request->id  as $key => $id) {
        DB::table('genarel_store_distribution_products')->insert(
            [
            'distributor_id'=>$request->d_id,
            'product_id'=>$request->id[$key],
            'date'=>$request->date,
            'qty'=>$request->qty[$key],
            'invoice_number'=>$invoice_number,
    ]);
    $product=Genarel_store_product::Find($request->id[$key]);
    $product->stock_unit -=$request->qty[$key];
    $product->save();
    }
    $data =Genarel_store_distribution::with('distributor')->where('invoice_number',$invoice_number)->get()->first();
    $id= $data->id;
$products=Genarel_store_distribution_product::where('invoice_number',$data->invoice_number)->get();
    $wing = 'g_store';
    return view('pages.sold_invoices_view', compact('wing','data','products','id'));
    }else{
    $distributor=new Genarel_store_distributior;
    $distributor->distributor_name=$request->name;
    $distributor->phone=$request->phone;
    $distributor->address=$request->address;
    $distributor->save();

    $product=Genarel_store_distributior::where('phone',$request->phone)->get()->first();
    $d_id=$product->id;
    
    $invoice= rand(1000, 9999);
    $invoice_number="d".$invoice;
    $user=Auth::user()->id;
    DB::table('genarel_store_distributions')->insert(
        [
   'distributor_id'=>$d_id,
//    'product_id'=>$request->id[$key],
//     'qty'=>$request->id[$key],
    'invoice_number'=>$invoice_number,
    'date'=>$request->date,
    'note'=>$request->note,
    'user_id'=>$user,
]);

     foreach ($request->id  as $key => $id) {
        DB::table('genarel_store_distribution_products')->insert(
            [
            'distributor_id'=>$d_id,
            'product_id'=>$request->id[$key],
            'date'=>$request->date,
            'qty'=>$request->qty[$key],
            'invoice_number'=>$invoice_number,
    ]);
    $product=Genarel_store_product::Find($request->id[$key]);
    $product->stock_unit -=$request->qty[$key];
    $product->save();
    }
    $data =Genarel_store_distribution::with('distributor')->where('invoice_number',$invoice_number)->get()->first();
    $id= $data->id;
    $products=Genarel_store_distribution_product::where('invoice_number',$data->invoice_number)->get();
    $wing = 'g_store';
    return view('pages.sold_invoices_view', compact('wing','data','products','id'));
}
   }
}