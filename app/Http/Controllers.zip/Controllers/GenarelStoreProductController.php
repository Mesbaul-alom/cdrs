<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Genarel_store_product;
use App\Models\Genarel_store_purchase;
class GenarelStoreProductController extends Controller
{
  public function productstore(Request $request){
 
    $randomNumber = random_int(100, 999);
    $code="GS".$randomNumber;
    $product=new Genarel_store_product;
    
	  $product->code =$code;	
    $product->product_title	= $request->name;
    $product->unit_name	=$request->unit;
    $product->description	=$request->description;
    $product->stock_unit = $request->qty;
    $product->opening_qty = $request->qty;
    $imageName = time().'.'.$request->image->extension();  
    $request->image->move(public_path('images'), $imageName);
    $product->image	=$imageName;
     $product->save();

     return redirect('/general-store/all-products')->with('success','product  add successfully');

  }

  public function product_edit($id){
    $wing = 't_store';
$product=Genarel_store_product::find($id);
return view('pages.product.edit',compact('product','wing'));

  } 
  public function product_view($id){
    $wing = 't_store';
    $product=Genarel_store_product::find($id);
    return view('pages.product.view',compact('product','wing'));
  } 
public function productupdate(Request $request){
  $product=Genarel_store_product::find($request->id);
  $product->product_title	= $request->name;
  $product->unit_name	=$request->unit;
  $product->description	=$request->description;
  // $product->stock_unit = $request->qty;
  if ($request->image) {
    $imageName = time().'.'.$request->image->extension();  
  $request->image->move(public_path('images'), $imageName);
  $product->image	=$imageName;
  }
  
   $product->save();

   return redirect('/general-store/all-products')->with('success','product  add successfully');
}

public function product_list_index(Request $request){
  dd($request);
  if ($request->ajax()) {

      $data = Genarel_store_purchase::with('supplier')->latest()->get();
      return Datatables::of($data)
      ->addIndexColumn()
      ->addColumn('action', function($row){
          $info = '';
         
                  $info .= '<a type="button" href="" class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
          return $info;
      })
  //   $data = Genarel_store_product::all();
  //   return Datatables::of($data)
  //   ->addIndexColumn()
  //   ->addColumn('action', function($row){
  //       $info = '';
       
  //               $info .= '<a type="button" href="" class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
  //       return $info;
  //   })
  //   ->addColumn('image', function($row){
  //     return '<img src="'.asset(optional($row)->image).'" style="width: 50px;" class="rounded" >';
  // })
  //   ->addColumn('name', function($row){
         
  //       return optional($row)->product_title;
  //   })
  //   ->addColumn('openingstock', function($row){
  //       return optional($row)->product_title; 
  //   })
  //   ->addColumn('currentstock', function($row){
  //       return optional($row)->stock_unit; 
  //   })
   
    ->rawColumns(['action'])
            ->make(true);
}
}

}
