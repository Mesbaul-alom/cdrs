<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Genarel_store_product;
use Illuminate\Support\Facades\DB;
use DataTables;
use App\Models\Genarel_store_distributior;
use App\Models\Genarel_store_distribution_product;
use App\Models\Genarel_store_distribution;
use App\Models\Genarel_store_purchase_product;
use App\Models\Genarel_store_purchase;
class GenarelStorePurchaseController extends Controller
{
   public function purchase_products_search(Request $request){

    $info = $request->info;
    $output = '';
    
    if(!empty($info)) {
         
        $info = DB::table('genarel_store_products')
                ->Where(function ($query) use ($info) {
                    $query->where('product_title', 'LIKE', '%'. $info. '%');
                })
                ->limit(15)
                ->get();

        if(count($info) > 0) {
            $output .= '<table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Action</th>
                                    <th scope="col"> Name</th>
                                </tr>
                            </thead>
                            <tbody>';
                            foreach ($info as $item) {
                                
                                $output.='<tr>'.
                                '<td><button type="button" onclick="add_product_data(\''.$item->product_title.'\',\''.$item->id.'\',\''.$item->image.'\',\''.$item->stock_unit.'\')" class="btn btn-primary btn-sm btn-rounded">Add</button></td>'.
                                '<td>
                             ' .$item->product_title.'
                                </td>'.
                                    
                                    
                                    '</tr>';
                                }
                            $output .= '</tbody>
                        </table>';

        }
        else {
            $output.='<h2 class="text-center">No Result Found</h2>';
        }
    }
    return Response($output);

   }
   public function supplier_search(Request $request){

    $info = $request->info;
    $output = '';
    
    if(!empty($info)) {
         
        $info = DB::table('suppliers')
                ->Where(function ($query) use ($info) {
                    $query->where('supplier_name', 'LIKE', '%'. $info. '%');
                })
                ->limit(15)
                ->get();

        if(count($info) > 0) {
            $output .= '<table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Action</th>
                                    <th scope="col"> Supplier Info</th>
                                </tr>
                            </thead>
                            <tbody>';
                            foreach ($info as $item) {
                                
                                $output.='<tr>'.
                                '<td><button type="button" onclick="add_supplier_data(\''.$item->supplier_name.'\',\''.$item->id.'\',\''.$item->phone.'\',\''.$item->company_name.'\')" class="btn btn-primary btn-sm btn-rounded">Add</button></td>'.
                                '<td>
                             ' .$item->supplier_name.'
                             ' .$item->company_name.'
                                </td>'.
                                    
                                    
                                    '</tr>';
                                }
                            $output .= '</tbody>
                        </table>';

        }
        else {
            $output.='<h2 class="text-center">No Result Found</h2>';
        }
    }
    return Response($output);

   }
   public function distributor_search(Request $request){

    $info = $request->info;
    $output = '';
    
    if(!empty($info)) {
         
        $info = DB::table('genarel_store_distributiors')
                ->Where(function ($query) use ($info) {
                    $query->where('phone', 'LIKE', '%'. $info. '%');
                })
                ->orWhere(function ($query) use ($info) {
                    $query->where('distributor_name', 'LIKE', '%'. $info. '%');
                })
                ->limit(15)
                ->get();

        if(count($info) > 0) {
            $output .= '<table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Action</th>
                                    <th scope="col">Distributor</th>
                                </tr>  
                            </thead>
                            <tbody>';
                            foreach ($info as $item) {
                                
                                $output.='<tr>'.
                                '<td><button type="button" onclick="add_distributor_data(\''.$item->distributor_name.'\',\''.$item->id.'\',\''.$item->phone.'\',\''.$item->address.'\')" class="btn btn-primary btn-sm btn-rounded">Add</button></td>'.
                                '<td>
                             ' .$item->distributor_name.'
                             ' .$item->phone.'
                                </td>'.
                                    
                                    
                                    '</tr>';
                                }
                            $output .= '</tbody>
                        </table>';

        }
        else {
            $output.='<h2 class="text-center">No Result Found</h2>';
        }
    }
    return Response($output);

   }
   public function purchase_list_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data = Genarel_store_purchase::with('supplier')->latest()->get();
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= '<a type="button" href="'.route('g.store.purchase.invoices.show', $row->id).'" class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
                return $info;
            })
            ->addColumn('day', function($row){
                 
                return date('d-m-Y', strtotime($row->date));
          })
            ->addColumn('supplierName', function($row){
                 
                  return optional($row)->supplier->supplier_name;
            })
            ->addColumn('phone', function($row){
                 
                return optional($row)->supplier->phone;
            })
            ->addColumn('invoicenumber', function($row){
                return optional($row)->invoice_number; 
            })
           
            ->rawColumns(['action','day', 'supplierName', 'phone','invoicenumber'])
                    ->make(true);
        }
      
        
    }
   public function distributor_list_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data =Genarel_store_distribution::with('distributor')->latest()->get();
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= '<a type="button" href="'.route('g.store.sold.invoices.view', $row->id).'" class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
                return $info;
            })
            ->addColumn('day', function($row){
                 
                  return date('d-m-Y', strtotime($row->date));
            })
            ->addColumn('customerName', function($row){
                 
                  return optional($row)->distributor->distributor_name;
            })
            ->addColumn('phone', function($row){
                 
                return optional($row)->distributor->phone;
            })
            ->addColumn('address', function($row){
                 
                return optional($row)->distributor->address;
            })
            ->addColumn('invoicenumber', function($row){
                return optional($row)->invoice_number; 
            })
           
            ->rawColumns(['action','day','customerName', 'phone','address','invoicenumber'])
                    ->make(true);
        }
      
        
    }
   public function distributor_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data =Genarel_store_distributior::all();
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= ' <a type="button" href="'.route('g.store.distributor.report.view', $row->id).'" class="btn btn-sm btn-warning">View Report</a> ';   
                        // $info .= '<a type="button"  class="btn btn-success btn-sm" ><i class="fas fa-eye"></i></a> ';   
                return $info;
            })
            ->addColumn('name', function($row){
                 
                  return optional($row)->distributor_name;
            })
            ->addColumn('phone', function($row){
                 
                return optional($row)->phone;
            })
            ->addColumn('address', function($row){
                 
                return optional($row)->address;
            })
           
           
            ->rawColumns(['action','name', 'phone','address'])
                    ->make(true);
        }
      
        
    }
   public function product_list_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data = Genarel_store_product::latest()->get();
            return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= '<a type="button"  href="'.route('g.store.product.edit', $row->id).'"  class="btn btn-success btn-sm rounded-pill" ><i class="fas fa-edit"></i></a><a type="button"  href="'.route('g.store.product.details', $row->id).'" class="btn btn-success btn-sm rounded-pill" ><i class="fas fa-eye"></i></a> ';   
                return $info;
            })
                ->addColumn('image', function($row){
            return '<img src="'.asset('/images/'.optional($row)->image).'" style="width: 50px;" class="rounded" >';
        })
            ->addColumn('name', function($row){
                
                return optional($row)->product_title;
            })
            ->addColumn('openingstock', function($row){
                return optional($row)->opening_qty  ; 
            })
            ->addColumn('currentstock', function($row){
                return optional($row)->stock_unit ; 
            })
            ->rawColumns(['action','image','name','openingstock','currentstock'])
                    ->make(true);
        }
      
        
    }
//    public function product_details_index(Request $request,$p_id)
//     {
   
//         if ($request->ajax()) {
//             $data = Genarel_store_purchase_product::where('product_id',$p_id)->get();
//             return Datatables::of($data)
           
//             ->addColumn('day', function($row){
                
//                 return optional($row)->date;
//             })
//             ->addColumn('openingstock', function($row){
//                 return optional($row)->qty  ; 
//             })
           
//             ->rawColumns(['day','qty'])
//                     ->make(true);
//         }
      
        
//     }
   public function product_report_index(Request $request)
    {
   
        if ($request->ajax()) {
            $data = Genarel_store_product::latest()->get();
            return Datatables::of($data)
            ->addIndexColumn()
     
            ->addColumn('action', function($row){
                $info = '';
               
                        $info .= '<a type="button"  href="'.route('g.store.product.details', $row->id).'"  class="btn btn-success btn-sm" >বিস্তারিত</a> ';   
                return $info;
            })
                ->addColumn('image', function($row){
            return '<img src="'.asset('/images/'.optional($row)->image).'" style="width: 50px;" class="rounded" >';
        })
            ->addColumn('name', function($row){
                
                return optional($row)->product_title;
            })
            ->addColumn('purchases', function($row){
                return $purchase=Genarel_store_purchase_product::where('product_id',$row->id)->sum('qty');  ; 
            })
            ->addColumn('distribute', function($row){
                return $purchase=Genarel_store_distribution_product::where('product_id',$row->id)->sum('qty');  ; 
            })
            ->addColumn('currentstock', function($row){
                return optional($row)->stock_unit ; 
            })
            ->rawColumns(['action','image','name','purchases','distribute','currentstock'])
                    ->make(true);
        }
      
        
    }
   




    public function product_details($id){
        $wing = 'g_store';
        $product=Genarel_store_product::where('id',$id)->first();
        $products=Genarel_store_purchase_product::where('product_id',$id)->paginate(10);
        $d_products=Genarel_store_distribution_product::where('product_id',$id)->paginate(10);
        return view('pages.product_details_report',compact('id','wing','products','d_products','product'));
    }
}
