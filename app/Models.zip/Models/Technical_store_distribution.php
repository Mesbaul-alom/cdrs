<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Technical_store_distribution extends Model
{
    use HasFactory;
    public function distributor()
    {
        return $this->belongsTo(Technical_store_distributor::class,'distributor_id','id');
    }
}
