<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Genarel_store_purchase_product extends Model
{

    use HasFactory;
}
