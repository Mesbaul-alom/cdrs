<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Genarel_store_distribution extends Model
{
    use HasFactory;
    public function distributor()
    {
        return $this->belongsTo(Genarel_store_distributior::class,'distributor_id','id');
    }
    
}
